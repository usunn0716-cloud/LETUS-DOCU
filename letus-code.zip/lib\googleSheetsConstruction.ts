import { google } from 'googleapis';

const SPREADSHEET_ID = process.env.GOOGLE_SHEETS_CONSTRUCTION_ID;
const CLIENT_EMAIL = process.env.GOOGLE_SHEETS_CLIENT_EMAIL;
const PRIVATE_KEY = process.env.GOOGLE_SHEETS_PRIVATE_KEY?.replace(/\\n/g, '\n');

const auth = new google.auth.GoogleAuth({
    credentials: {
        client_email: CLIENT_EMAIL,
        private_key: PRIVATE_KEY,
    },
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
});

const sheets = google.sheets({ version: 'v4', auth });

// ===== 시공팀 등록 현황 시트 (권역장 / 택배기사 분리) =====
const COMMON_HEADERS = [
    '제출일시', '소속센터', '소속영업소', '이름', '생년월일', '연락처', '이메일', '주소',
    '차명', '차량번호', '연료', '차량형태', '번호판구분', '번호판종류(용도)', '이산화탄소배출량',
    '화물운송종사자격증번호', '종사자격증 취득일', '적재함형태/적재량', '운전면허종류', '운전면허번호',
    '상태'
];

const MANAGER_DOCS = [
    '사업자등록증', '위수탁계약서', '부속합의서', '사무실 임대(전대)차계약서', '사무실 전대차 동의서',
    '영업소 등기부등본', '산재보험가입증명원', '자동차등록증', '화물운송종사 자격증', '운전면허증',
    '안전교육 이수증', '화물운송 허가증', '택배기사 명부', '영업소 전경 사진'
];

const DRIVER_DOCS = [
    '위수탁계약서', '부속합의서', '사업자등록증', '산재보험가입증명원', '안전교육 이수증',
    '자동차등록증', '화물운송종사 자격증', '운전면허증', '화물운송 허가증'
];

export const MANAGER_HEADERS = [...COMMON_HEADERS, ...MANAGER_DOCS.map(d => `서류링크_${d}`)];
export const DRIVER_HEADERS = [...COMMON_HEADERS, ...DRIVER_DOCS.map(d => `서류링크_${d}`)];

export function getSheetName(role?: string): string {
    if (role === 'manager') return '권역장등록현황';
    return '시공팀등록현황'; // 택배기사 및 기존 유저 통합
}

export function getHeaders(role?: string): string[] {
    if (role === 'manager') return MANAGER_HEADERS;
    if (role === 'driver') return DRIVER_HEADERS;
    return [...COMMON_HEADERS, '서류링크_기타'];
}

// ===== 권역장 비밀번호 시트 =====
const PASSWORD_SHEET = '권역장비밀번호';

// ===== 유틸리티 =====
function colLetter(index: number): string {
    if (index < 26) return String.fromCharCode(65 + index);
    return 'A' + String.fromCharCode(65 + (index - 26));
}

// [수정] 특정 셀 범위만 업데이트하는 헬퍼 함수
// 전체 행을 읽고 쓰는 대신, 필요한 열만 정확히 지정해서 부분 업데이트
async function updateCells(
    sheetName: string,
    row: number,
    updates: { col: string; value: string }[]
): Promise<void> {
    if (!SPREADSHEET_ID || updates.length === 0) return;

    const data = updates.map(u => ({
        range: `${sheetName}!${u.col}${row}`,
        values: [[u.value]],
    }));

    await sheets.spreadsheets.values.batchUpdate({
        spreadsheetId: SPREADSHEET_ID,
        requestBody: {
            valueInputOption: 'USER_ENTERED',
            data,
        },
    });
}

// [수정] 특정 셀 범위만 RAW 모드로 업데이트 (문자열 보존용)
async function updateCellsRaw(
    sheetName: string,
    row: number,
    updates: { col: string; value: string }[]
): Promise<void> {
    if (!SPREADSHEET_ID || updates.length === 0) return;

    const data = updates.map(u => ({
        range: `${sheetName}!${u.col}${row}`,
        values: [[u.value]],
    }));

    await sheets.spreadsheets.values.batchUpdate({
        spreadsheetId: SPREADSHEET_ID,
        requestBody: {
            valueInputOption: 'RAW',
            data,
        },
    });
}

// ===== 헤더 확인 및 시트 생성 =====
async function ensureSheet(sheetName: string, headers: string[]): Promise<void> {
    if (!SPREADSHEET_ID) return;
    const endCol = colLetter(headers.length - 1);
    try {
        const res = await sheets.spreadsheets.values.get({
            spreadsheetId: SPREADSHEET_ID,
            range: `${sheetName}!A1:BZ1`, // 넉넉하게 스캔
        });
        const firstRow = res.data.values?.[0] || [];
        // 기존 헤더가 다르거나 짧으면 전체 덮어쓰기
        if (firstRow.length < headers.length || firstRow.slice(0, headers.length).join(',') !== headers.join(',')) {
            await sheets.spreadsheets.values.update({
                spreadsheetId: SPREADSHEET_ID,
                range: `${sheetName}!A1:${colLetter(headers.length - 1)}1`,
                valueInputOption: 'USER_ENTERED',
                requestBody: { values: [headers] },
            });
        }
    } catch {
        try {
            await sheets.spreadsheets.batchUpdate({
                spreadsheetId: SPREADSHEET_ID,
                requestBody: {
                    requests: [{ addSheet: { properties: { title: sheetName } } }]
                }
            });
            await sheets.spreadsheets.values.update({
                spreadsheetId: SPREADSHEET_ID,
                range: `${sheetName}!A1:${colLetter(headers.length - 1)}1`,
                valueInputOption: 'USER_ENTERED',
                requestBody: { values: [headers] },
            });
        } catch (innerError) {
            console.error(`[Construction Sheets] "${sheetName}" 시트 생성 실패:`, innerError);
        }
    }
}

// ===== 동일인 행 찾기 (이름+생년월일+연락처) =====
function normalizeDigits(val: string): string {
    return val.replace(/\D/g, '').replace(/^0+/, '');
}

async function findExistingRow(sheetName: string, name: string, birthday: string, phone: string): Promise<number> {
    try {
        const res = await sheets.spreadsheets.values.get({
            spreadsheetId: SPREADSHEET_ID!,
            range: `${sheetName}!D:F`, // [수정] D=이름, E=생년월일, F=연락처만 읽기 (A:F → D:F)
        });
        const rows = res.data.values;
        if (!rows || rows.length <= 1) return -1;

        const inputName = name.trim();
        const inputBirth = normalizeDigits(birthday);
        const inputPhone = normalizeDigits(phone);

        for (let i = 1; i < rows.length; i++) {
            const rName = (rows[i][0] || '').toString().trim();      // D열 = 인덱스 0
            const rBirth = normalizeDigits((rows[i][1] || '').toString()); // E열 = 인덱스 1
            const rPhone = normalizeDigits((rows[i][2] || '').toString()); // F열 = 인덱스 2

            if (rName === inputName && rBirth === inputBirth && rPhone === inputPhone) {
                return i + 1; // 시트 행 번호 (1-based, 헤더 제외)
            }
        }
        return -1;
    } catch {
        return -1;
    }
}

// ===== [수정] 개인정보 저장 — A~H열만 정확히 부분 업데이트 =====
export async function savePersonalInfo(data: any) {
    if (!SPREADSHEET_ID) throw new Error("SPREADSHEET_ID is not set");
    const sheetName = getSheetName(data.role);
    const headers = getHeaders(data.role);
    await ensureSheet(sheetName, headers);

    const now = new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' });
    const existingRow = await findExistingRow(sheetName, data.name, data.birthday, data.phone);

    if (existingRow > 0) {
        // [수정] 기존 행: A~H열만 부분 업데이트 (I열 이후 절대 건드리지 않음)
        await updateCellsRaw(sheetName, existingRow, [
            { col: 'A', value: now },
            { col: 'B', value: data.center || '' },
            { col: 'C', value: data.subRegion || '' },
            { col: 'D', value: data.name || '' },
            { col: 'E', value: data.birthday || '' },
            { col: 'F', value: data.phone || '' },
            { col: 'G', value: data.email || '' },
            { col: 'H', value: data.address || '' },
        ]);
    } else {
        // [수정] 새 행: 정확히 헤더 개수만큼 생성, 각 위치에 맞게 배치
        const rowData = new Array(headers.length).fill('');
        rowData[0] = now;                        // A: 제출일시
        rowData[1] = data.center || '';           // B: 소속센터
        rowData[2] = data.subRegion || '';        // C: 소속영업소
        rowData[3] = data.name || '';             // D: 이름
        rowData[4] = data.birthday || '';         // E: 생년월일
        rowData[5] = data.phone || '';            // F: 연락처
        rowData[6] = data.email || '';            // G: 이메일
        rowData[7] = data.address || '';          // H: 주소
        // I~T (8~19): 차량/자격증/면허 → 빈칸 유지 (OCR이 채움)
        rowData[20] = '재직 중';                   // U: 상태
        // V이후: 서류링크 → 빈칸 유지

        await sheets.spreadsheets.values.append({
            spreadsheetId: SPREADSHEET_ID,
            range: `${sheetName}!A1`,
            valueInputOption: 'RAW',
            requestBody: { values: [rowData] },
        });
    }
}

// ===== [수정] 차량정보만 업데이트 — 해당 열만 정확히 부분 업데이트 =====
export async function updateVehicleInfo(data: any) {
    if (!SPREADSHEET_ID) throw new Error("SPREADSHEET_ID is not set");
    const sheetName = getSheetName(data.role);
    const headers = getHeaders(data.role);
    await ensureSheet(sheetName, headers);

    const existingRow = await findExistingRow(sheetName, data.name, data.birthday, data.phone);
    if (existingRow <= 0) {
        throw new Error("개인정보가 먼저 등록되어야 합니다.");
    }

    const now = new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' });

    // [수정] 값이 있는 필드만 골라서 해당 열만 업데이트
    const updates: { col: string; value: string }[] = [
        { col: 'A', value: now }, // 제출일시 갱신
    ];

    if (data.vehicleName) updates.push({ col: 'I', value: data.vehicleName });   // 차명
    if (data.licensePlate) updates.push({ col: 'J', value: data.licensePlate });   // 차량번호
    if (data.fuelType) updates.push({ col: 'K', value: data.fuelType });       // 연료
    if (data.vehicleType) updates.push({ col: 'L', value: data.vehicleType });    // 차량형태
    if (data.plateType) updates.push({ col: 'M', value: data.plateType });      // 번호판구분
    if (data.platePurpose) updates.push({ col: 'N', value: data.platePurpose });  // 번호판종류(용도)
    if (data.co2Emission) updates.push({ col: 'O', value: data.co2Emission });    // 이산화탄소배출량
    if (data.loadingCapacity) updates.push({ col: 'R', value: data.loadingCapacity }); // 적재함형태/적재량

    await updateCells(sheetName, existingRow, updates);
}

// ===== 서류 링크 업데이트 (변경 없음 — 이미 단일 셀 업데이트) =====
export async function updateDocumentLinks(data: {
    name: string;
    birthday: string;
    phone: string;
    docType: string;
    fileUrl: string;
    center?: string;
    subRegion?: string;
    role?: string;
}) {
    if (!SPREADSHEET_ID) throw new Error("SPREADSHEET_ID is not set");
    const sheetName = getSheetName(data.role);
    const headers = getHeaders(data.role);
    await ensureSheet(sheetName, headers);

    let existingRow = await findExistingRow(sheetName, data.name, data.birthday, data.phone);
    if (existingRow <= 0) {
        console.warn('[Construction Sheets] 서류 링크 업데이트: 해당 사용자 행이 없어 새로 생성합니다.');
        await savePersonalInfo({
            name: data.name,
            birthday: data.birthday,
            phone: data.phone,
            center: data.center || '',
            subRegion: data.subRegion || '',
            role: data.role,
        });
        existingRow = await findExistingRow(sheetName, data.name, data.birthday, data.phone);
        if (existingRow <= 0) {
            console.error('[Construction Sheets] 행 생성 후에도 찾을 수 없습니다.');
            return;
        }
    }

    // 동적으로 컬럼 인덱스 찾기
    const res = await sheets.spreadsheets.values.get({
        spreadsheetId: SPREADSHEET_ID,
        range: `${sheetName}!A1:BZ1`,
    });
    const headerRow = res.data.values?.[0] || [];
    
    // docType과 서류링크 헤더명 매칭 ("사무실 임대(전대)차계약서" -> "서류링크_사무실 임대(전대)차계약서")
    const searchHeader = `서류링크_${data.docType}`;
    let colIndex = headerRow.findIndex(h => h.trim() === searchHeader);
    
    // 유연한 매칭 (택배기사의 "위수탁계약서 및 부속합의서" 등의 경우를 대비)
    if (colIndex === -1) {
        colIndex = headerRow.findIndex(h => {
            const cleanH = h.replace('서류링크_', '').trim();
            if (!cleanH) return false;
            return cleanH.includes(data.docType) || data.docType.includes(cleanH);
        });
    }

    if (colIndex === -1) {
        // 만약 못찾았다면, 빈 컬럼을 찾아서 헤더를 추가합니다.
        colIndex = headerRow.length;
        const newColLetter = colLetter(colIndex);
        await sheets.spreadsheets.values.update({
            spreadsheetId: SPREADSHEET_ID,
            range: `${sheetName}!${newColLetter}1`,
            valueInputOption: 'USER_ENTERED',
            requestBody: { values: [[searchHeader]] },
        });
    }

    const col = colLetter(colIndex);

    await sheets.spreadsheets.values.update({
        spreadsheetId: SPREADSHEET_ID,
        range: `${sheetName}!${col}${existingRow}`,
        valueInputOption: 'USER_ENTERED',
        requestBody: { values: [[data.fileUrl]] },
    });
    console.log(`[Construction Sheets] 서류 링크 업데이트: ${data.name} / ${data.docType} → ${col}${existingRow}`);
}

// ===== 전체 데이터 조회 (두 시트 병합) =====
export async function getConstructionTeams(center?: string, subRegion?: string) {
    if (!SPREADSHEET_ID) return [];
    try {
        const roles = ['manager', 'driver'];
        let allTeams: any[] = [];

        for (const role of roles) {
            const sheetName = getSheetName(role);
            const headers = getHeaders(role);
            await ensureSheet(sheetName, headers);

            // 동일한 시트(시공팀등록현황)를 여러 번 조회하지 않도록 방지
            if (allTeams.some(t => t.sheetName === sheetName)) continue;

            const res = await sheets.spreadsheets.values.get({
                spreadsheetId: SPREADSHEET_ID,
                range: `${sheetName}!A:BZ`, // 서류링크가 많으므로 BZ까지 넉넉히
            });
            const rows = res.data.values;
            if (!rows || rows.length <= 1) continue;

            const headerRow = rows[0];

            let teams = rows.slice(1).map((row, index) => {
                const teamData: any = {
                    id: `${role}_${index + 2}`, // role과 row 인덱스 조합 (e.g. manager_2)
                    role: role,
                    sheetName: sheetName,
                    submittedAt: row[0] || '',
                    center: row[1] || '',
                    subRegion: row[2] || '',
                    name: row[3] || '',
                    birthday: row[4] || '',
                    phone: row[5] || '',
                    email: row[6] || '',
                    address: row[7] || '',
                    vehicleName: row[8] || '',
                    licensePlate: row[9] || '',
                    fuelType: row[10] || '',
                    vehicleType: row[11] || '',
                    plateType: row[12] || '',
                    platePurpose: row[13] || '',
                    co2Emission: row[14] || '',
                    cargoLicenseNum: row[15] || '',
                    cargoLicenseDate: row[16] || '',
                    loadingCapacity: row[17] || '',
                    driverLicenseType: row[18] || '',
                    driverLicenseNum: row[19] || '',
                    status: row[20] || '재직 중',
                };

                // 헤더를 순회하며 서류 링크를 동적으로 매핑
                for (let i = 21; i < headerRow.length; i++) {
                    const colName = headerRow[i];
                    if (colName && colName.startsWith('서류링크_')) {
                        const docName = colName.replace('서류링크_', '');
                        teamData[`doc_${docName}`] = row[i] || '';
                    }
                }

                // 기존 프론트엔드 하위 호환성을 위해 자주 쓰이는 서류들은 고정 필드에도 매핑
                teamData.docBusiness = teamData[`doc_사업자등록증`] || '';
                teamData.docContract = teamData[`doc_위수탁계약서`] || teamData[`doc_위수탁계약서 및 부속합의서`] || '';
                teamData.docVehicle = teamData[`doc_자동차등록증`] || '';
                teamData.docDriver = teamData[`doc_운전면허증`] || '';
                teamData.docCargo = teamData[`doc_화물운송종사 자격증`] || teamData[`doc_화물운송종사자격증`] || '';
                teamData.docOther = teamData[`doc_기타`] || teamData[`doc_안전교육 이수증`] || '';

                return teamData;
            });

            allTeams = allTeams.concat(teams);
        }

        if (subRegion) {
            allTeams = allTeams.filter(t => t.subRegion === subRegion);
        } else if (center) {
            allTeams = allTeams.filter(t => t.center === center);
        }

        return allTeams;
    } catch (error) {
        console.error("Error fetching teams:", error);
        return [];
    }
}

// ===== 상태 변경 =====
export async function updateConstructionTeamStatus(rowIndex: number, status: string, role?: string) {
    if (!SPREADSHEET_ID) return;
    const sheetName = getSheetName(role);
    await sheets.spreadsheets.values.update({
        spreadsheetId: SPREADSHEET_ID,
        range: `${sheetName}!U${rowIndex}`,
        valueInputOption: 'USER_ENTERED',
        requestBody: { values: [[status]] },
    });
}

// ===== [수정] OCR / 수동입력 데이터 — 서류별 해당 열만 정확히 부분 업데이트 =====
export async function updateOCRData(data: {
    name: string;
    birthday: string;
    phone: string;
    docType: string;
    extractedData: Record<string, string>;
    role?: string;
}) {
    if (!SPREADSHEET_ID) throw new Error("SPREADSHEET_ID is not set");
    const sheetName = getSheetName(data.role);
    const headers = getHeaders(data.role);
    await ensureSheet(sheetName, headers);

    const existingRow = await findExistingRow(sheetName, data.name, data.birthday, data.phone);
    if (existingRow <= 0) {
        console.warn('[Construction Sheets] 데이터 업데이트: 해당 사용자 행을 찾을 수 없음', data.name);
        return;
    }

    const { extractedData, docType } = data;
    const updates: { col: string; value: string }[] = [];

    // [수정] 값이 유효할 때만 해당 열에 추가
    const addIfValid = (col: string, ...candidates: (string | undefined)[]) => {
        for (const val of candidates) {
            if (val && val !== '확인불가') {
                updates.push({ col, value: val });
                return;
            }
        }
    };

    if (docType === '운전면허증' || docType === '자동차운전면허증') {
        addIfValid('H', extractedData['거주지주소']);                                   // H: 주소
        addIfValid('S', extractedData['운전면허종류']);                                  // S: 운전면허종류
        addIfValid('T', extractedData['운전면허번호']);                                  // T: 운전면허번호
    } else if (docType === '자동차등록증') {
        addIfValid('I', extractedData['차량명'], extractedData['차명']);                  // I: 차명
        addIfValid('J', extractedData['차량번호'], extractedData['자동차등록번호']);        // J: 차량번호
        addIfValid('K', extractedData['연료종류'], extractedData['연료의종류'], extractedData['연료']); // K: 연료
        addIfValid('L', extractedData['차량종류'], extractedData['차량형태'], extractedData['차종']);    // L: 차량형태
        addIfValid('N', extractedData['번호판종류'], extractedData['용도'], extractedData['번호판종류(용도)']); // N: 번호판종류
        addIfValid('O', extractedData['이산화탄소배출량'], extractedData['CO2배출량']);     // O: CO2
        addIfValid('R', extractedData['적재함형태_적재량'], extractedData['최대적재량'], extractedData['적재함형태/적재량']); // R: 적재함
    } else if (docType === '화물운송종사 자격증' || docType === '화물운송종사자격증') {
        addIfValid('P', extractedData['화물운송종사자격증번호'], extractedData['자격증번호'], extractedData['종사자격번호']); // P: 자격증번호
        addIfValid('Q', extractedData['종사자격증취득일'], extractedData['취득일자'], extractedData['자격취득일']);             // Q: 취득일
    } else if (docType === '위수탁계약서') {
        addIfValid('G', extractedData['이메일']);                                        // G: 이메일
    }

    if (updates.length > 0) {
        await updateCells(sheetName, existingRow, updates);
        console.log(`[Construction Sheets] 데이터 업데이트 완료: ${data.name} / ${data.docType} → ${updates.map(u => u.col).join(',')}`);
    }
}

// ===== 행 삭제 =====
export async function deleteConstructionTeamRow(rowIndex: number, role?: string) {
    if (!SPREADSHEET_ID) return;
    const sheetName = getSheetName(role);

    const spreadsheet = await sheets.spreadsheets.get({
        spreadsheetId: SPREADSHEET_ID,
        fields: 'sheets.properties',
    });
    const targetSheet = spreadsheet.data.sheets?.find(
        s => s.properties?.title === sheetName
    );
    if (targetSheet?.properties?.sheetId === undefined) return;

    await sheets.spreadsheets.batchUpdate({
        spreadsheetId: SPREADSHEET_ID,
        requestBody: {
            requests: [{
                deleteDimension: {
                    range: {
                        sheetId: targetSheet.properties.sheetId,
                        dimension: 'ROWS',
                        startIndex: rowIndex - 1,
                        endIndex: rowIndex,
                    }
                }
            }]
        }
    });
}

// ===== 권역장 비밀번호 관리 (변경 없음) =====

const PASSWORD_HEADERS = ['센터명', '영업소명', '비밀번호'];

const ALL_OFFICES = [
    { center: '양지센터(B2C)', sub: '양지6영업소((주)디에스엔지니어)' },
    { center: '양지센터(B2C)', sub: '양지7영업소((주)서현테크)' },
    { center: '양지센터(B2C)', sub: '양지8영업소(스타일룸)' },
    { center: '양지센터(B2C)', sub: '양지12영업소(TY서비스)' },
    { center: '양지센터(B2C)', sub: '양지2_2영업소(엠케이프로젝트퍼니처)' },
    { center: '양지센터(B2C)', sub: '양지23영업소(일룸)' },
    { center: '양지센터(B2C)', sub: '양지13영업소' },
    { center: '양지센터(B2C)', sub: '양지9영업소(그랑팩토리)' },
    { center: '양지센터(B2C)', sub: '안성1영업소(유빈산업)' },
    { center: '양지센터(B2C)', sub: '양지22영업소(에이와이가구)' },
    { center: '양지센터(B2C)', sub: '양지2_1영업소(요다프렌즈)' },
    { center: '양지센터(B2B)', sub: '양지14영업소(LHS)' },
    { center: '양지센터(B2B)', sub: '양지15영업소(CMS 프로모션)' },
    { center: '양지센터(B2B)', sub: '양지16영업소(오성)' },
    { center: '양지센터(B2B)', sub: '양지17영업소(온찬유통)' },
    { center: '양지센터(B2B)', sub: '양지18영업소(모든퍼니처)' },
    { center: '양지센터(B2B)', sub: '양지19영업소(드래곤)' },
    { center: '양지센터(B2B)', sub: '양지20영업소(정인유통)' },
    { center: '지방센터', sub: '부산1영업소(태인유통)' },
    { center: '지방센터', sub: '부산(기장)2영업소(태준유통)' },
    { center: '지방센터', sub: '전남1영업소(스마일유통)' },
    { center: '지방센터', sub: '창원1영업소(정빈유통)' },
    { center: '지방센터', sub: '울산1영업소(수연유통)' },
    { center: '지방센터', sub: '제주1영업소(스마일유통)' },
    { center: '대구센터', sub: '대구1영업소(투윈스)' },
    { center: '대구센터', sub: '대구2영업소(대구가구)' },
    { center: '대구센터', sub: '대구3영업소(형제유통)' },
    { center: '대구센터', sub: '대구4영업소(석퍼시스)' },
    { center: '대전센터', sub: '대전1영업소(주식회사오제이더블유)' },
    { center: '대전센터', sub: '대전2영업소(주식회사에스엔티)' },
    { center: '대전센터', sub: '대전3영업소(주식회사티오피플랜)' },
    { center: '대전센터', sub: '대전4영업소(무빙인)' },
    { center: '대전센터', sub: '대전5영업소(비비디)' },
    { center: '광주센터', sub: '광주1영업소(주식회사와이에스유통)' },
    { center: '광주센터', sub: '광주2영업소(FIT퍼니처)' },
    { center: '광주센터', sub: '전북1영업소(대영)' },
];

async function ensurePasswordSheet(): Promise<void> {
    await ensureSheet(PASSWORD_SHEET, PASSWORD_HEADERS);

    try {
        const res = await sheets.spreadsheets.values.get({
            spreadsheetId: SPREADSHEET_ID!,
            range: `${PASSWORD_SHEET}!A:Z`,
        });
        const rows = res.data.values;
        const header = rows?.[0] || [];

        const isCorrectFormat = header.length >= 3
            && header[0]?.toString().trim() === '센터명'
            && header[1]?.toString().trim() === '영업소명'
            && header[2]?.toString().trim() === '비밀번호';

        if (isCorrectFormat && rows && rows.length > 1) {
            return;
        }

        console.log('[Construction Sheets] 비밀번호 시트 포맷 불일치 — 전체 초기화 시작');

        const clearRange = rows && rows.length > 0
            ? `${PASSWORD_SHEET}!A1:Z${rows.length + 10}`
            : `${PASSWORD_SHEET}!A1:Z100`;
        await sheets.spreadsheets.values.clear({
            spreadsheetId: SPREADSHEET_ID!,
            range: clearRange,
        });

        const allData = [
            PASSWORD_HEADERS,
            ...ALL_OFFICES.map(o => [o.center, o.sub, '1234']),
        ];
        await sheets.spreadsheets.values.update({
            spreadsheetId: SPREADSHEET_ID!,
            range: `${PASSWORD_SHEET}!A1`,
            valueInputOption: 'RAW',
            requestBody: { values: allData },
        });

        console.log('[Construction Sheets] 비밀번호 시트 초기화 완료 ✓ (영업소 단위, 기본: 1234)');
    } catch (error) {
        console.error('[Construction Sheets] 비밀번호 시트 초기화 실패:', error);
    }
}

export async function verifyRegionPassword(subRegion: string, password: string): Promise<boolean> {
    if (!SPREADSHEET_ID) return false;
    await ensurePasswordSheet();

    try {
        const res = await sheets.spreadsheets.values.get({
            spreadsheetId: SPREADSHEET_ID,
            range: `${PASSWORD_SHEET}!A:C`,
        });
        const rows = res.data.values;
        if (!rows || rows.length <= 1) return false;

        for (let i = 1; i < rows.length; i++) {
            const rowSub = (rows[i][1] || '').toString().trim();
            const rowPw = (rows[i][2] || '').toString().trim();
            if (rowSub === subRegion.trim() && rowPw === password.trim()) {
                return true;
            }
        }
        return false;
    } catch {
        return false;
    }
}

export async function getRegionPasswords(): Promise<{ center: string; subRegion: string; password: string }[]> {
    if (!SPREADSHEET_ID) return [];
    await ensurePasswordSheet();

    try {
        const res = await sheets.spreadsheets.values.get({
            spreadsheetId: SPREADSHEET_ID,
            range: `${PASSWORD_SHEET}!A:C`,
        });
        const rows = res.data.values;
        if (!rows || rows.length <= 1) return [];

        return rows.slice(1).map(row => ({
            center: row[0] || '',
            subRegion: row[1] || '',
            password: (row[2] || '').toString(),
        }));
    } catch {
        return [];
    }
}

export async function updateRegionPassword(subRegion: string, newPassword: string): Promise<boolean> {
    if (!SPREADSHEET_ID) return false;
    await ensurePasswordSheet();

    try {
        const res = await sheets.spreadsheets.values.get({
            spreadsheetId: SPREADSHEET_ID,
            range: `${PASSWORD_SHEET}!A:C`,
        });
        const rows = res.data.values;
        if (!rows || rows.length <= 1) return false;

        for (let i = 1; i < rows.length; i++) {
            if ((rows[i][1] || '').toString().trim() === subRegion.trim()) {
                await sheets.spreadsheets.values.update({
                    spreadsheetId: SPREADSHEET_ID,
                    range: `${PASSWORD_SHEET}!C${i + 1}`,
                    valueInputOption: 'RAW',
                    requestBody: { values: [[newPassword]] },
                });
                return true;
            }
        }
        return false;
    } catch {
        return false;
    }
}

