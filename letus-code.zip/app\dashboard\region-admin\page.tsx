"use client";

import React, { useState, useEffect, useMemo, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Home, Search, Archive, Trash2, RefreshCw, ChevronDown, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

function RegionAdminDashboardContent() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const center = searchParams.get("center") || "";
    const subRegion = searchParams.get("subRegion") || "";

    const [teams, setTeams] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [filterName, setFilterName] = useState("");
    const [filterPlate, setFilterPlate] = useState("");
    const [archivedExpanded, setArchivedExpanded] = useState(false);

    const fetchTeams = async () => {
        setIsLoading(true);
        try {
            const params = new URLSearchParams();
            if (center) params.set("center", center);
            if (subRegion) params.set("subRegion", subRegion);
            const res = await fetch(`/api/construction-sheet?${params.toString()}`);
            if (res.ok) setTeams(await res.json());
        } catch (e) { console.error(e); }
        finally { setIsLoading(false); }
    };

    useEffect(() => {
        if (!center && !subRegion) { router.push("/"); return; }
        fetchTeams();
    }, [center, subRegion]);

    const filteredTeams = useMemo(() => teams.filter(t =>
        t.status !== "보관"
        && t.name.toLowerCase().includes(filterName.trim().toLowerCase())
        && (t.licensePlate || "").toLowerCase().includes(filterPlate.trim().toLowerCase())
    ), [teams, filterName, filterPlate]);

    const archivedTeams = useMemo(() => teams.filter(t => t.status === "보관"), [teams]);
    const activeTeams = useMemo(() => teams.filter(t => t.status !== "보관"), [teams]);

    const postAction = async (body: any) => {
        const res = await fetch("/api/construction-sheet", {
            method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
        });
        if (res.ok) fetchTeams(); else alert("처리에 실패했습니다.");
    };

    const handleUpdateStatus = (id: string, cur: string) => {
        const [role, rowIndexStr] = id.split('_');
        postAction({ action: "updateStatus", rowIndex: parseInt(rowIndexStr, 10), role, status: cur === "재직 중" ? "퇴사" : "재직 중" });
    };

    const handleArchive = (id: string) => {
        if (!confirm("이 기사를 보관 처리하시겠습니까?")) return;
        const [role, rowIndexStr] = id.split('_');
        postAction({ action: "updateStatus", rowIndex: parseInt(rowIndexStr, 10), role, status: "보관" });
    };

    const handleRestore = (id: string) => {
        const [role, rowIndexStr] = id.split('_');
        postAction({ action: "updateStatus", rowIndex: parseInt(rowIndexStr, 10), role, status: "재직 중" });
    };

    const handleDelete = async (id: string, name: string) => {
        if (!confirm(`정말 ${name} 기사를 영구 삭제하시겠습니까?`)) return;
        const [role, rowIndexStr] = id.split('_');
        const res = await fetch(`/api/construction-sheet?rowIndex=${rowIndexStr}&role=${role}`, { method: "DELETE" });
        if (res.ok) fetchTeams(); else alert("삭제에 실패했습니다.");
    };

    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-50">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                    <p className="text-slate-500 font-medium">데이터를 불러오는 중...</p>
                </div>
            </div>
        );
    }

    /* 공통 테이블 컴포넌트 */
    const TeamTable = ({ data, showRestore }: { data: any[]; showRestore?: boolean }) => (
        <div className="overflow-x-auto">
            <table className="w-full text-left text-xs whitespace-nowrap">
                <thead className="bg-slate-50 border-b">
                    <tr>
                        <th className="p-2.5 pl-4 font-medium text-slate-500">이름</th>
                        <th className="p-2.5 font-medium text-slate-500">생년월일</th>
                        <th className="p-2.5 font-medium text-slate-500">연락처</th>
                        <th className="p-2.5 font-medium text-slate-500">이메일</th>
                        <th className="p-2.5 font-medium text-slate-500">주소</th>
                        <th className="p-2.5 font-medium text-slate-500">차명</th>
                        <th className="p-2.5 font-medium text-slate-500">차량번호</th>
                        <th className="p-2.5 font-medium text-slate-500">연료</th>
                        <th className="p-2.5 font-medium text-slate-500">차량형태</th>
                        <th className="p-2.5 font-medium text-slate-500">번호판</th>
                        <th className="p-2.5 font-medium text-slate-500">CO₂</th>
                        <th className="p-2.5 text-center font-medium text-slate-500">재직</th>
                        <th className="p-2.5 pr-4 text-center font-medium text-slate-500">관리</th>
                    </tr>
                </thead>
                <tbody className="divide-y">
                    {data.length === 0 ? (
                        <tr><td colSpan={13} className="p-8 text-center text-slate-400">데이터가 없습니다.</td></tr>
                    ) : data.map((t, i) => (
                        <tr key={t.id || i} className="bg-white hover:bg-slate-50 transition-colors">
                            <td className="p-2.5 pl-4 font-bold text-slate-800">{t.name}</td>
                            <td className="p-2.5 text-slate-600">{t.birthday || "-"}</td>
                            <td className="p-2.5 text-slate-600">{t.phone}</td>
                            <td className="p-2.5 text-slate-500">{t.email || "-"}</td>
                            <td className="p-2.5 text-slate-500 max-w-[120px] truncate" title={t.address}>{t.address || "-"}</td>
                            <td className="p-2.5 text-slate-600">{t.vehicleName || "-"}</td>
                            <td className="p-2.5 font-medium text-blue-600">{t.licensePlate || "-"}</td>
                            <td className="p-2.5 text-slate-600">{t.fuelType || "-"}</td>
                            <td className="p-2.5 text-slate-600">{t.vehicleType || "-"}</td>
                            <td className="p-2.5 text-slate-600">{t.plateType || "-"}</td>
                            <td className="p-2.5 text-slate-600">{t.co2Emission || "-"}</td>
                            <td className="p-2.5 text-center">
                                {showRestore ? (
                                    <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-slate-200 text-slate-500">보관</span>
                                ) : (
                                    <button
                                        onClick={() => handleUpdateStatus(t.id, t.status)}
                                        className={`px-2 py-0.5 rounded-full text-xs font-bold ${t.status === "재직 중" ? "bg-blue-100 text-blue-700 hover:bg-blue-200" : "bg-red-100 text-red-700 hover:bg-red-200"}`}
                                    >{t.status}</button>
                                )}
                            </td>
                            <td className="p-2.5 pr-4 text-center">
                                <div className="flex items-center justify-center gap-1">
                                    {showRestore ? (
                                        <button onClick={() => handleRestore(t.id)} className="p-1.5 rounded-md bg-blue-50 text-blue-500 hover:bg-blue-100" title="복원">
                                            <RotateCcw className="w-3.5 h-3.5" />
                                        </button>
                                    ) : (
                                        <button onClick={() => handleArchive(t.id)} className="p-1.5 rounded-md bg-slate-100 text-slate-600 hover:bg-slate-200" title="보관">
                                            <Archive className="w-3.5 h-3.5" />
                                        </button>
                                    )}
                                    <button onClick={() => handleDelete(t.id, t.name)} className="p-1.5 rounded-md bg-red-50 text-red-500 hover:bg-red-100" title="삭제">
                                        <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );

    return (
        <div className="min-h-screen bg-slate-50">
            {/* Header */}
            <div className="bg-letus-black text-white p-6 pb-12">
                <div className="max-w-7xl mx-auto">
                    <div className="flex justify-between items-center mb-6">
                        <div>
                            <h1 className="text-2xl font-bold">권역장 대시보드</h1>
                            <p className="text-blue-400 text-sm mt-1 font-medium">{subRegion || center}</p>
                            <p className="text-slate-500 text-xs mt-0.5">{center} · 소속 시공팀 현황 및 차량 관리</p>
                        </div>
                        <Button variant="ghost" className="text-white hover:bg-white/10" onClick={() => router.push("/")}>
                            <Home className="h-4 w-4 mr-2" /> 초기화면
                        </Button>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                        <div className="bg-white/10 rounded-xl p-4">
                            <div className="text-3xl font-bold text-blue-400">{activeTeams.filter(t => t.status === "재직 중").length}<span className="text-sm font-normal text-slate-400 ml-1">명</span></div>
                            <div className="text-xs text-slate-400 mt-1">재직 중인 기사</div>
                        </div>
                        <div className="bg-white/10 rounded-xl p-4">
                            <div className="text-3xl font-bold text-red-400">{activeTeams.filter(t => t.status === "퇴사").length}<span className="text-sm font-normal text-slate-400 ml-1">명</span></div>
                            <div className="text-xs text-slate-400 mt-1">퇴사 처리됨</div>
                        </div>
                        <div className="bg-white/10 rounded-xl p-4">
                            <div className="text-3xl font-bold text-slate-400">{activeTeams.length}<span className="text-sm font-normal text-slate-500 ml-1">명</span></div>
                            <div className="text-xs text-slate-500 mt-1">총 등록자</div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="max-w-7xl mx-auto px-4 -mt-6 pb-12 space-y-4">
                {/* 시공팀 등록 목록 */}
                <Card className="shadow-lg border-0">
                    <CardHeader className="pb-3 border-b bg-white rounded-t-xl">
                        <div className="flex items-center justify-between flex-wrap gap-2">
                            <CardTitle className="text-lg flex items-center gap-2">
                                시공팀 등록 목록
                                <span className="text-xs font-normal text-slate-400 ml-1">{filteredTeams.length}명</span>
                            </CardTitle>
                            <div className="flex items-center gap-2">
                                <Button variant="outline" size="sm" onClick={fetchTeams} className="text-xs">
                                    <RefreshCw className="w-3.5 h-3.5 mr-1" /> 새로고침
                                </Button>
                                <div className="relative">
                                    <Search className="w-4 h-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                                    <Input placeholder="이름 검색" className="pl-8 h-8 text-xs w-32" value={filterName} onChange={e => setFilterName(e.target.value)} />
                                </div>
                                <div className="relative">
                                    <Search className="w-4 h-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                                    <Input placeholder="차량번호 검색" className="pl-8 h-8 text-xs w-32" value={filterPlate} onChange={e => setFilterPlate(e.target.value)} />
                                </div>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent className="p-0">
                        <TeamTable data={filteredTeams} />
                    </CardContent>
                </Card>

                {/* 보관 목록 (접이식) */}
                <Card className="shadow border-0">
                    <CardHeader
                        className="cursor-pointer hover:bg-slate-50 transition-colors rounded-xl py-4"
                        onClick={() => setArchivedExpanded(!archivedExpanded)}
                    >
                        <div className="flex items-center justify-between">
                            <CardTitle className="text-base flex items-center gap-2 text-slate-600">
                                <Archive className="w-4 h-4 text-slate-400" />
                                보관 목록
                                <span className="text-xs font-normal text-slate-400">{archivedTeams.length}명</span>
                            </CardTitle>
                            <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${archivedExpanded ? "rotate-180" : ""}`} />
                        </div>
                    </CardHeader>
                    {archivedExpanded && (
                        <CardContent className="p-0 border-t">
                            <TeamTable data={archivedTeams} showRestore />
                        </CardContent>
                    )}
                </Card>
            </div>
        </div>
    );
}

export default function RegionAdminDashboard() {
    return (
        <Suspense fallback={
            <div className="min-h-screen flex items-center justify-center bg-slate-50">
                <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
            </div>
        }>
            <RegionAdminDashboardContent />
        </Suspense>
    );
}
